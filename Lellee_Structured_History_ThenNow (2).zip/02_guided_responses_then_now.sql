-- LELLEE SPRINT: Structured Guided Responses + Then & Now
-- Run in Supabase SQL Editor after the Foundation schema.

begin;

create table if not exists public.guided_responses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,

  -- Where in the recovery journey this response occurred
  response_date date not null default current_date,
  recovery_day integer,
  phase_key text,
  curriculum_day integer,
  content_slug text,

  -- Stable identifiers make future comparison possible even if wording changes.
  prompt_key text not null,
  prompt_version integer not null default 1,
  prompt_text text not null,

  -- Guided interaction data
  selected_choices jsonb not null default '[]'::jsonb,
  optional_reflection text,

  -- Controls for future resurfacing / printed Recovery Story
  allow_milestone_review boolean not null default true,
  allow_recovery_story boolean not null default false,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  unique(user_id, response_date, prompt_key)
);

create index if not exists idx_guided_responses_user_date
  on public.guided_responses(user_id, response_date desc);

create index if not exists idx_guided_responses_user_prompt
  on public.guided_responses(user_id, prompt_key, response_date);

create index if not exists idx_guided_responses_user_phase
  on public.guided_responses(user_id, phase_key, curriculum_day);

alter table public.guided_responses enable row level security;

drop policy if exists "guided_responses_select_own" on public.guided_responses;
create policy "guided_responses_select_own"
on public.guided_responses for select to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "guided_responses_insert_own" on public.guided_responses;
create policy "guided_responses_insert_own"
on public.guided_responses for insert to authenticated
with check ((select auth.uid()) = user_id);

drop policy if exists "guided_responses_update_own" on public.guided_responses;
create policy "guided_responses_update_own"
on public.guided_responses for update to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

drop policy if exists "guided_responses_delete_own" on public.guided_responses;
create policy "guided_responses_delete_own"
on public.guided_responses for delete to authenticated
using ((select auth.uid()) = user_id);

revoke all on table public.guided_responses from anon;
revoke all on table public.guided_responses from authenticated;
grant select, insert, update, delete on table public.guided_responses to authenticated;

-- Add updated_at trigger using the Foundation function.
drop trigger if exists set_updated_at on public.guided_responses;
create trigger set_updated_at
before update on public.guided_responses
for each row execute function public.set_updated_at();

-- Milestone review records: stores the user's own reflection on comparisons.
create table if not exists public.milestone_reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  milestone_key text not null,
  milestone_date date not null default current_date,
  recovery_day integer,
  title text not null,
  comparison_snapshot jsonb not null default '{}'::jsonb,
  selected_observations jsonb not null default '[]'::jsonb,
  reflection text,
  allow_recovery_story boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, milestone_key)
);

create index if not exists idx_milestone_reviews_user
  on public.milestone_reviews(user_id, milestone_date desc);

alter table public.milestone_reviews enable row level security;

drop policy if exists "milestone_reviews_select_own" on public.milestone_reviews;
create policy "milestone_reviews_select_own"
on public.milestone_reviews for select to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "milestone_reviews_insert_own" on public.milestone_reviews;
create policy "milestone_reviews_insert_own"
on public.milestone_reviews for insert to authenticated
with check ((select auth.uid()) = user_id);

drop policy if exists "milestone_reviews_update_own" on public.milestone_reviews;
create policy "milestone_reviews_update_own"
on public.milestone_reviews for update to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

drop policy if exists "milestone_reviews_delete_own" on public.milestone_reviews;
create policy "milestone_reviews_delete_own"
on public.milestone_reviews for delete to authenticated
using ((select auth.uid()) = user_id);

revoke all on table public.milestone_reviews from anon;
revoke all on table public.milestone_reviews from authenticated;
grant select, insert, update, delete on table public.milestone_reviews to authenticated;

drop trigger if exists set_updated_at on public.milestone_reviews;
create trigger set_updated_at
before update on public.milestone_reviews
for each row execute function public.set_updated_at();

commit;
